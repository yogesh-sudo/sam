import React from 'react'

const Contact = () => {
    return (
        <div>
              <div>
        {/*Start breadcrumb area*/}     
        <section className="breadcrumb-area" style={{backgroundImage: 'url(images/resources/breadcrumb-bg.jpg)'}}>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="breadcrumbs">
                  <h1>Contact</h1>
                </div>
              </div>
            </div>
          </div>
          <div className="breadcrumb-botton">
            <div className="container">
              <div className="row">
                <div className="col-md-12">
                  <ul className="left pull-left">
                    <li><a href="/">Home</a></li>
                    <li><i className="fa fa-angle-right" aria-hidden="true" /></li>
                    <li className="active">Contact</li>
                  </ul>
                  <div className="share-button pull-right">
                    <a href="#"><i className="fa fa-share-alt" aria-hidden="true" />Share</a>    
                  </div>    
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*End breadcrumb area*/}
        {/*Start contact form area*/}
        <section className="contact-form-area">
          <div className="container">
            <div className="sec-title">
              <h1>Get Touch With Us</h1>
              <span className="border" />
              <div className="select-box pull-right">
                <select className="text-capitalize selectpicker form-control required" name="form_subject" data-style="g-select" data-width="100%">
                  <option>Newyork Office</option>
                  <option>Canada Office</option>
                  <option>UK Office</option>
                  <option>USA Office</option>
                </select>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-8 col-md-7">
                <div className="contact-form">
                  <form id="contact-form" name="contact_form" className="default-form" action="inc/sendmail.php" method="post">
                    <h2>Send Message Us</h2>
                    <div className="row">
                      <div className="col-md-6">
                        <input type="text" name="form_name" defaultValue={""} placeholder="Your Name*" required />
                      </div>
                      <div className="col-md-6">
                        <input type="email" name="form_email" defaultValue={""} placeholder="Your Mail*" required />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-6">
                        <input type="text" name="form_phone" defaultValue={""} placeholder="Phone" />
                      </div>
                      <div className="col-md-6">
                        <input type="text" name="form_subject" defaultValue={""} placeholder="Subject" />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-12">
                        <textarea name="form_message" placeholder="Your Message.." required defaultValue={""} />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-md-12">
                        <input id="form_botcheck" name="form_botcheck" className="form-control" type="hidden" defaultValue />
                        <button className="thm-btn bg-clr1" type="submit" data-loading-text="Please wait...">send message</button>
                      </div>
                    </div>
                  </form>  
                </div>
              </div>
              <div className="col-lg-4 col-md-5">
                <div className="quick-contact">
                  <div className="title">
                    <h2>Quick Contact</h2>
                    <p>If you have any questions simply use the following contact details.</p>
                  </div>
                  <ul className="contact-info">
                    <li>
                      <div className="icon-holder">
                        <span className="flaticon-arrows" />
                      </div>
                      <div className="text-holder">
                        <h5><span>Address:</span> Flat No. 505 Shivlok 
<br />Apartment Sector-21D, Faridabad-121001</h5>
                      </div>
                    </li>
                    <li>
                      <div className="icon-holder">
                        <span className="flaticon-phone" />
                      </div>
                      <div className="text-holder">
                        <h5><span>Phone:</span> (123) 0200 12345 &amp;<br />1800-45-678-9012</h5>
                      </div>
                    </li>
                    <li>
                      <div className="icon-holder">
                        <span className="flaticon-back" />
                      </div>
                      <div className="text-holder">
                        <h5><span>Email:</span> Mailus@Factoryteam.com</h5>
                      </div>
                    </li>
                  </ul>
                  <ul className="social-links">
                    <li><a href="#"><i className="fa fa-facebook" /></a></li>
                    <li><a href="#"><i className="fa fa-twitter" /></a></li>
                    <li><a href="#"><i className="fa fa-google-plus" /></a></li>
                    <li><a href="#"><i className="fa fa-pinterest-p" /></a></li>
                    <li><a href="#"><i className="fa fa-youtube" /></a></li>
                  </ul>
                </div>    
              </div>
            </div>
          </div>
        </section>
        {/*End contact form area*/}  
        {/*Start Google map area*/}
        <section className="google-map-area">
          <div className="google-map" id="contact-google-map" data-map-lat="44.529688" data-map-lng="-72.933009" data-icon-path="images/resources/map-marker.png" data-map-title="Brooklyn, New York, United Kingdom" data-map-zoom={12} data-markers="{
            &quot;marker-1&quot;: [44.529688, -72.933009, &quot;<h4>Head Office</h4><p>44/108 Brooklyn, UK</p>&quot;],
            &quot;marker-2&quot;: [44.231172, -76.485954, &quot;<h4>Branch Office</h4><p>4/99 Alabama, USA</p>&quot;]
        }">
          </div>
        </section>
        {/*End Google map area*/}
      </div>
        </div>
    )
}

export default Contact
