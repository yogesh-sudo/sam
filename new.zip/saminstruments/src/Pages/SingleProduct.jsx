import React from 'react'

const SingleProduct = () => {
    return (
        <div>
             <div>
        {/*Start breadcrumb area*/}     
        <section className="breadcrumb-area" style={{backgroundImage: 'url(images/resources/breadcrumb-bg.jpg)'}}>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="breadcrumbs">
                  <h1>Project Single</h1>
                </div>
              </div>
            </div>
          </div>
          <div className="breadcrumb-botton">
            <div className="container">
              <div className="row">
                <div className="col-md-12">
                  <ul className="left pull-left">
                    <li><a href="/">Home</a></li>
                    <li><i className="fa fa-angle-right" aria-hidden="true" /></li>
                    <li className="active">Project Single</li>
                  </ul>
                  <div className="share-button pull-right">
                    <a href="#"><i className="fa fa-share-alt" aria-hidden="true" />Share</a>    
                  </div>    
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*End breadcrumb area*/}  
        {/*Start project single v2 area*/}
        <section id="project-single-area">
          <div className="container">
            <div className="row">
              <div className="col-md-8">
                {/*Start single project item*/}
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/project-single-1.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <div className="icon-holder">
                            <a href="images/projects/project-single-1.jpg" data-rel="prettyPhoto" title="Industry Project">
                              <i className="fa fa-search" aria-hidden="true" />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div> 
                </div>
                {/*End single project item*/}
                {/*Start single project item*/}
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/project-single-2.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <div className="icon-holder">
                            <a href="images/projects/project-single-2.jpg" data-rel="prettyPhoto" title="Industry Project">
                              <i className="fa fa-search" aria-hidden="true" />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div> 
                </div>
                {/*End single project item*/}
                {/*Start single project item*/}
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/project-single-3.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <div className="icon-holder">
                            <a href="images/projects/project-single-3.jpg" data-rel="prettyPhoto" title="Industry Project">
                              <i className="fa fa-search" aria-hidden="true" />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div> 
                </div>
                {/*End single project item*/}
              </div>
              <div className="col-md-4">
                <div className="project-info">
                  <div className="sec-title">
                    <h1>Description</h1>
                    <span className="border" />
                  </div>
                  <p>How all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, builder of human happiness.<br /><br />Great explorer of the truth, the master-builder of human happinessbut because those who do not to pursue seds pleasure rationally encounter.</p>
                  <ul className="project-info-list">
                    <li>
                      <div className="icon-holder">
                        <i className="fa fa-user" aria-hidden="true" />
                      </div>
                      <div className="text-holder">
                        <h5>Author</h5>
                        <p>Chaz Reubhen</p>
                      </div>
                    </li>
                    <li>
                      <div className="icon-holder">
                        <i className="fa fa-folder-open" aria-hidden="true" />
                      </div>
                      <div className="text-holder">
                        <h5>Category</h5>
                        <p>Manufacturing</p>
                      </div>
                    </li>
                    <li>
                      <div className="icon-holder">
                        <i className="fa fa-calendar" aria-hidden="true" />
                      </div>
                      <div className="text-holder">
                        <h5>Start Date</h5>
                        <p>26th Jan 2017</p>
                      </div>
                    </li>
                    <li>
                      <div className="icon-holder">
                        <i className="fa fa-calendar" aria-hidden="true" />
                      </div>
                      <div className="text-holder">
                        <h5>End Date</h5>
                        <p>06st Feb 2017</p>
                      </div>
                    </li>
                    <li>
                      <div className="icon-holder">
                        <i className="fa fa-usd" aria-hidden="true" />
                      </div>
                      <div className="text-holder">
                        <h5>Showcase Link</h5>
                        <p>www.demo.com</p>
                      </div>
                    </li>
                    <li>
                      <div className="icon-holder">
                        <i className="fa fa-map-marker" aria-hidden="true" />
                      </div>
                      <div className="text-holder">
                        <h5>Location</h5>
                        <p>Newyork City, USA</p>
                      </div>
                    </li>
                  </ul>
                  <div className="share-project">
                    <div className="title">
                      <h5>Share:</h5>
                    </div>
                    <div className="social-share">
                      <ul>
                        <li><a href="#"><i className="fa fa-facebook" aria-hidden="true" /></a></li>
                        <li><a href="#"><i className="fa fa-twitter" aria-hidden="true" /></a></li>
                        <li><a href="#"><i className="fa fa-google-plus" aria-hidden="true" /></a></li>
                        <li><a href="#"><i className="fa fa-youtube" aria-hidden="true" /></a></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="row bottom">
              <div className="col-md-4 col-sm-4 col-xs-4">
                <div className="button prev pull-left">
                  <a href="#"><i className="fa fa-angle-left" aria-hidden="true" />Prev</a>    
                </div>
              </div>
              <div className="col-md-4 col-sm-4 col-xs-4">
                <div className="icon-holder text-center">
                  <a href="#">
                    <i className="fa fa-th" aria-hidden="true" />
                  </a>
                </div>
              </div>
              <div className="col-md-4 col-sm-4 col-xs-4">
                <div className="button next pull-right">
                  <a href="#">Next<i className="fa fa-angle-right" aria-hidden="true" /></a>    
                </div>
              </div>
            </div>                                          
          </div>
        </section>                                                                      
        {/*End project single v2 area*/}
      </div>
        </div>
    )
}

export default SingleProduct
