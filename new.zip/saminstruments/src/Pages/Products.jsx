import React from 'react'
import { Link } from 'react-router-dom'
const Products = () => {
    return (
        <div>
             <div>
        {/*Start breadcrumb area*/}     
        <section className="breadcrumb-area" style={{backgroundImage: 'url(images/resources/breadcrumb-bg.jpg)'}}>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="breadcrumbs">
                  <h1>Our Products</h1>
                </div>
              </div>
            </div>
          </div>
          <div className="breadcrumb-botton">
            <div className="container">
              <div className="row">
                <div className="col-md-12">
                  <ul className="left pull-left">
                    <li><a href="/">Home</a></li>
                    <li><i className="fa fa-angle-right" aria-hidden="true" /></li>
                    <li className="active">Projects</li>
                  </ul>
                  <div className="share-button pull-right">
                    <Link to="#"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>    
                  </div>    
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*End breadcrumb area*/}     
        {/*Start project with text area*/} 
        <section className="main-project-area">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <ul className="project-filter post-filter text-center">
                  <li className="active" data-filter=".filter-item"><span>View All (12)</span></li>
                  <li data-filter=".technology"><span>Technology</span></li>
                  <li data-filter=".chemical"><span>Chemical</span></li>
                  <li data-filter=".agriculture"><span>Agriculture</span></li>
                  <li data-filter=".environment"><span>Environment</span></li>
                  <li data-filter=".material"><span>Material Science</span></li>
                </ul>
              </div>
            </div>
            <div className="row project-content masonary-layout filter-layout">
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item chemical environment technology">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/1.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item material environment technology">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/2.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item chemical environment material">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/3.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item material technology">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/4.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item chemical agriculture technology">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/5.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item agriculture material chemical">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/6.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item chemical material agriculture">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/7.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item chemical agriculture material environment">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/8.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item agriculture technology material">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/9.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item agriculture chemical technology">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/10.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item chemical agriculture technology">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/11.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
              {/*Start single project item*/}
              <div className="col-md-3 col-sm-4 col-xs-12 filter-item agriculture technology material">
                <div className="single-project-item">
                  <div className="img-holder">
                    <img src="images/projects/12.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <Link to="/products/product">View Project</Link>
                          <div className="text-holder">
                            <h4>Pre Construction</h4>
                            <p>Material</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single project item*/}
            </div>
            <div className="row">
              <div className="col-md-12"> 
                <ul className="post-pagination text-center">
                  <li><Link to="#"><i className="fa fa-caret-left" aria-hidden="true" /></Link></li>
                  <li className="active"><Link to="#">1</Link></li>
                  <li><Link to="#">2</Link></li>
                  <li><Link to="#">3</Link></li>
                  <li><Link to="#"><i className="fa fa-caret-right" aria-hidden="true" /></Link></li>
                </ul>
              </div> 
            </div>
          </div>
        </section>                            
        {/*End project with text area*/}
      </div>
        </div>
    )
}

export default Products
