import React from 'react'

const Home = () => {
    return (
        <div>
            
            {/*Start rev slider wrapper*/}     
            <section className="rev_slider_wrapper">
        <div id="slider1" className="rev_slider" data-version={5.0}>
          <ul>
            <li data-transition="random">
              <img src="images/slides/1.jpg" alt="" width={1920} height={600} data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax={1} />
              <div className="tp-caption  tp-resizeme" data-x="left" data-hoffset={0} data-y="top" data-voffset={145} data-transform_idle="o:1;" data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-start={700}>
                <div className="slide-content-box mar-lft">
                  <h1>The most targetted<br />industrial theme</h1>
                </div>
              </div>
              <div className="tp-caption  tp-resizeme" data-x="left" data-hoffset={0} data-y="top" data-voffset={298} data-transform_idle="o:1;" data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-start={2000}>
                <div className="slide-content-box mar-lft">
                  <p>Industry has consistently embraced innovation to provide a superior<br />level of excellence for all over valuable customers</p>
                </div>
              </div>
              <div className="tp-caption tp-resizeme" data-x="left" data-hoffset={0} data-y="top" data-voffset={383} data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-start={2900}>
                <div className="slide-content-box mar-lft">
                  <div className="button">
                    <a className="thm-btn bg-clr1" href="#">Our Solutions</a>     
                    <a className="thm-btn bg-clr2 remdmore" href="#">Read More</a>     
                  </div>
                </div>
              </div>
            </li>
            <li data-transition="random">
              <img src="images/slides/2.jpg" alt="" width={1920} height={600} data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax={1} />
              <div className="tp-caption tp-resizeme slogan" data-x="center" data-hoffset={0} data-y="center" data-voffset={-90} data-transform_idle="o:1;" data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" data-splitin="none" data-splitout="none" data-start={500}>
                <div className="slide-content-box middle-slide">
                  <h1>We are manufacturing products<br /> with world class quality</h1>
                </div>
              </div>
              <div className="tp-caption tp-resizeme" data-x="center" data-hoffset={0} data-y="center" data-voffset={25} data-transform_idle="o:1;" data-transform_in="x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:[-100%];y:0;s:inherit;e:inherit;" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-start={1500}>
                <div className="slide-content-box middle-slide">
                  <p>Industry has consistently embraced innovation to provide a superior level of<br />excellence for all over valuable customers</p>
                </div>
              </div>
              <div className="tp-caption tp-resizeme" data-x="center" data-hoffset={0} data-y="center" data-voffset={110} data-transform_idle="o:1;" data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-start={2300}>
                <div className="slide-content-box middle-slide">
                  <div className="button">
                    <a className="thm-btn bg-clr1" href="#">Our Solutions</a>     
                    <a className="thm-btn bg-clr2 remdmore" href="#">Read More</a>     
                  </div>    
                </div>
              </div>
            </li>
            <li data-transition="random">
              <img src="images/slides/3.jpg" alt="" width={1920} height={600} data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax={1} />
              <div className="tp-caption  tp-resizeme" data-x="right" data-hoffset={0} data-y="top" data-voffset={145} data-transform_idle="o:1;" data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-start={700}>
                <div className="slide-content-box lastslide">
                  <h1>Provide solutions<br />for all industries</h1>
                  <p>Industry has consistently embraced innovation to provide a superior<br />level of excellence for all over valuable customers.</p>
                  <div className="button">
                    <a className="thm-btn bg-clr1" href="#">Our Solutions</a> 
                    <a className="thm-btn bg-clr2 remdmore" href="#">Read More</a>      
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </section>
      {/*End rev slider wrapper*/}

      
      {/*Start welcome area*/}  
      <section className="welcome-area">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="welcome-content">
                <div className="title">
                  <h1>Welcome<br /> to our <span>industry</span></h1>
                </div>
                <div className="text">
                  <p>We have facility to produce advance work various industrial applications based on specially developed technol-ogy. We are also ready to developement by according to users changing needs. Infrastructure related installation projects. General repair &amp; industrial and machinery.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/*End welcome area*/}
      
      {/*Start solution area*/}
      <section className="solution-area">
        <div className="container">
          <div className="row">
            {/*Start single item*/}
            <div className="col-md-4">
              <div className="single-solution-item">
                <div className="title-holder">
                  <h3>Agriculture Processing</h3>
                  <p>Technoeconomic Activities</p>
                  <span className="border" />
                </div>
                <div className="img-holder">
                  <img src="images/solutions/1.jpg" alt="Awesome Image" />
                  <div className="overlay-style-one">
                    <div className="box">
                      <div className="content">
                        <a href="#">Read More</a>
                      </div>
                    </div>
                  </div>
                  <div className="icon-holder">
                    <span className="flaticon-halloween" />
                  </div>
                </div>
                <div className="text-holder">
                  <p>Agriculrure processing is the transformation of raw ingredients, by physical...</p>
                </div>
              </div>
            </div>
            {/*End single item*/}
            {/*Start single item*/}
            <div className="col-md-4">
              <div className="single-solution-item">
                <div className="title-holder">
                  <h3>Mechanical Engineering</h3>
                  <p>Manufacturing &amp; Maintenance</p>
                  <span className="border" />
                </div>
                <div className="img-holder">
                  <img src="images/solutions/2.jpg" alt="Awesome Image" />
                  <div className="overlay-style-one">
                    <div className="box">
                      <div className="content">
                        <a href="#">Read More</a>
                      </div>
                    </div>
                  </div>
                  <div className="icon-holder">
                    <span className="flaticon-damper" />
                  </div>
                </div>
                <div className="text-holder">
                  <p>There are four basic production processes for producing desired shape of a product...</p>
                </div>
              </div>
            </div>
            {/*End single item*/}
            {/*Start single item*/}
            <div className="col-md-4">
              <div className="single-solution-item">
                <div className="title-holder">
                  <h3>Chemical Research</h3>
                  <p>Pharmaceutical Sectors</p>
                  <span className="border" />
                </div>
                <div className="img-holder">
                  <img src="images/solutions/3.jpg" alt="Awesome Image" />
                  <div className="overlay-style-one">
                    <div className="box">
                      <div className="content">
                        <a href="#">Read More</a>
                      </div>
                    </div>
                  </div>
                  <div className="icon-holder">
                    <span className="flaticon-science" />
                  </div>
                </div>
                <div className="text-holder">
                  <p>We offers chemical R&amp;D services to the fine chemical, pharmaceutical &amp; biotech...</p>
                </div>
              </div>
            </div>
            {/*End single item*/}
          </div>
        </div>
        <div className="container solution-botton">
          <div className="row">
            {/*Start single item*/}
            <div className="col-md-4">
              <div className="single-item hvr-float-shadow">
                <div className="img-holder">
                  <img src="images/solutions/solution-thumb-1.jpg" alt="Awesome Image" />
                </div>
                <div className="text-holder">
                  <h3>Petroleum and Gas</h3> 
                  <p>Production of hydrocarbons</p>
                  <a href="#"><span className="flaticon-arrows-1" />Read More</a>
                </div>
              </div>
            </div>
            {/*End single item*/}
            {/*Start single item*/}
            <div className="col-md-4">
              <div className="single-item hvr-float-shadow">
                <div className="img-holder">
                  <img src="images/solutions/solution-thumb-2.jpg" alt="Awesome Image" />
                </div>
                <div className="text-holder">
                  <h3>Material Engineering</h3> 
                  <p>Development of materials</p>
                  <a href="#"><span className="flaticon-arrows-1" />Read More</a>
                </div>
              </div>
            </div>
            {/*End single item*/} 
            {/*Start single item*/}
            <div className="col-md-4">
              <div className="single-item hvr-float-shadow">
                <div className="img-holder">
                  <img src="images/solutions/solution-thumb-3.jpg" alt="Awesome Image" />
                </div>
                <div className="text-holder">
                  <h3>Power and Energy</h3> 
                  <p>From sunlight into electricity</p>
                  <a href="#"><span className="flaticon-arrows-1" />Read More</a>
                </div>
              </div>
            </div>
            {/*End single item*/}         
          </div>
        </div>
      </section>
      {/*End solution area*/}
      {/*Start latest project area*/}
      <section className="latest-project-area">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="top">
                <div className="sec-title pull-left">
                  <h1>Latest Projects</h1>
                  <span className="border" />
                </div>
                <ul className="project-filter post-filter pull-right">
                  <li className="active" data-filter=".filter-item"><span>View All</span></li>
                  <li data-filter=".agriculture"><span>agriculture</span></li>
                  <li data-filter=".chemical"><span>chemical</span></li>
                  <li data-filter=".materials"><span>Materials</span></li>
                  <li data-filter=".mechanical"><span>Mechanical</span></li>
                </ul>
              </div>
            </div>
          </div>
          <div className="row project-content masonary-layout filter-layout">
            {/*Start single item*/}
            <div className="col-md-3 col-sm-6 col-xs-12 filter-item materials chemical">
              <div className="single-project-item">
                <div className="img-holder">
                  <img src="images/projects/latest-project-1.jpg" alt="Awesome Image" />
                  <div className="overlay-style-one">
                    <div className="box">
                      <div className="content">
                        <a href="/products/product">View Project</a>
                        <div className="text-holder">
                          <h4>Pre Construction</h4>
                          <p>Material</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>   
              </div>
            </div>
            {/*End single item*/}
            {/*Start single item*/}
            <div className="col-md-3 col-sm-6 col-xs-12 filter-item mechanical materials agriculture">
              <div className="single-project-item">
                <div className="img-holder">
                  <img src="images/projects/latest-project-2.jpg" alt="Awesome Image" />
                  <div className="overlay-style-one">
                    <div className="box">
                      <div className="content">
                        <a href="/products/product">View Project</a>
                        <div className="text-holder">
                          <h4>Pre Construction</h4>
                          <p>Material</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>   
              </div>
            </div>
            {/*End single item*/}
            {/*Start single item*/}
            <div className="col-md-3 col-sm-6 col-xs-12 filter-item agriculture chemical mechanical">
              <div className="single-project-item">
                <div className="img-holder">
                  <img src="images/projects/latest-project-3.jpg" alt="Awesome Image" />
                  <div className="overlay-style-one">
                    <div className="box">
                      <div className="content">
                        <a href="/products/product">View Project</a>
                        <div className="text-holder">
                          <h4>Pre Construction</h4>
                          <p>Material</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>   
              </div>
            </div>
            {/*End single item*/}
            {/*Start single item*/}
            <div className="col-md-3 col-sm-6 col-xs-12 filter-item agriculture mechanical chemical">
              <div className="single-project-item">
                <div className="img-holder">
                  <img src="images/projects/latest-project-4.jpg" alt="Awesome Image" />
                  <div className="overlay-style-one">
                    <div className="box">
                      <div className="content">
                        <a href="/products/product">View Project</a>
                        <div className="text-holder">
                          <h4>Pre Construction</h4>
                          <p>Material</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>   
              </div>
            </div>
            {/*End single item*/}
          </div>     
        </div>
      </section>
      {/*End latest project area*/}
        {/*Start about industry area*/}  
        <section className="about-industry-area">
        <div className="container">
          <div className="row">
            <div className="col-md-8">
              <div className="sec-title">
                <h1>About Our Industry</h1>
                <span className="border" />
              </div>
              <div className="row">
                <div className="col-md-4">
                  <div className="img-holder">
                    <img src="images/about/industry.jpg" alt="Awesome Image" />
                  </div>
                </div>
                <div className="col-md-8">
                  <div className="text-holder">
                    <p>When you give to Our Industry, know your donation is making a difference whether you are supporting our signature Programs or our carefully curated list of gifts that professional.</p>
                    <div className="title">
                      <h2>Hsitory in Words</h2>
                    </div>
                    <p>We partner with over 320 amazing seds projects worldwide, and have given over million in cash &amp; product grants to other groups since 2015 our own dynamic suite.</p>
                    <p>There anyone who loves or pursues or desires to obtain pain of it is because seds all occasionally circumstances.</p>
                    <a className="readmore thm-btn bg-clr1" href="#">Read More</a>    
                  </div>    
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <form id="quote-form" action="#">
                <div className="sec-title text-center">
                  <h1>Request for Quote</h1>
                  <span className="border center" />
                </div>
                <div className="row">
                  <div className="col-md-12">
                    <input type="text" name="form_name" defaultValue placeholder="Your Name*" required />
                    <input type="email" name="form_email" defaultValue placeholder="Your Mail*" required />
                    <select className="selectmenu">
                      <option selected="selected">Select Service</option>
                      <option>Agriculture Processing</option>
                      <option>Mechanical Engineering</option>
                      <option>Chemical Research</option>
                      <option>Petroleum and Gas</option>
                      <option>Material Engineering</option>
                      <option>Power and Energy</option>
                    </select>
                    <button className="thm-btn bg-clr1" type="submit">Get a Quote</button>
                  </div>  
                </div>    
              </form>    
            </div>
          </div>
        </div>
      </section> 
      {/*End about industry area*/}

       {/*Start Testimonial area*/}
       <section className="testimonial-area">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="top">
                <div className="sec-title pull-left">
                  <h1>Words From Customers</h1>
                  <span className="border" />
                </div>
                <div className="more-project pull-right">
                  <a href="projects">More Reviews</a>    
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            {/*Start single item*/}
            <div className="col-md-6">
              <div className="single-item">
                <div className="icon-holder">
                  <i className="fa fa-quote-left" aria-hidden="true" />
                </div>
                <div className="inner-box">
                  <div className="text-box">
                    <p>The Industry has helped us to just have a better handle on everything in our business – to actually make decisions and move foward to grow business  teachings of the great explorer of the truth.</p>
                  </div>
                  <div className="bottom">
                    <div className="client-info pull-left">
                      <div className="client-photo">
                        <img src="images/resources/review-1.png" alt="Awesome Image" />
                      </div>
                      <div className="text">
                        <h3>Jenifer Hearly</h3>
                        <span>Oklahoma City</span>
                      </div>
                    </div>
                    <div className="review-box pull-right">
                      <ul>
                        <li><i className="fa fa-star" /></li>
                        <li><i className="fa fa-star" /></li>
                        <li><i className="fa fa-star" /></li>
                        <li><i className="fa fa-star" /></li>
                        <li><i className="fa fa-star" /></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/*End single item*/} 
            {/*Start single item*/}
            <div className="col-md-6">
              <div className="single-item">
                <div className="icon-holder">
                  <i className="fa fa-quote-left" aria-hidden="true" />
                </div>
                <div className="inner-box">
                  <div className="text-box">
                    <p>Anyone who loves or pursues desires to obtain pain of itself, because it is pain, but because occasionally our circumstances occur in which toil and pain can procure except advantage.</p>
                  </div>
                  <div className="bottom">
                    <div className="client-info pull-left">
                      <div className="client-photo">
                        <img src="images/resources/review-2.png" alt="Awesome Image" />
                      </div>
                      <div className="text">
                        <h3>Parker Smith</h3>
                        <span>California</span>
                      </div>
                    </div>
                    <div className="review-box pull-right">
                      <ul>
                        <li><i className="fa fa-star" /></li>
                        <li><i className="fa fa-star" /></li>
                        <li><i className="fa fa-star" /></li>
                        <li><i className="fa fa-star" /></li>
                        <li><i className="fa fa-star" /></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/*End single item*/}     
          </div>
        </div>
      </section>
      {/*End Testimonial area*/}

       {/*Start latest blog area*/}  
       {/* <section className="latest-blog-area">
        <div className="container">
          <div className="sec-title text-center">
            <h1>Latest News</h1>
            <span className="border center" />
          </div>  
          <div className="row">
            <div className="col-md-8">
              <div className="latest-blog-left">
                <div className="row"> */}
                  {/*Start single blog item*/}
                  {/* <div className="col-md-6">
                    <div className="single-blog-item">
                      <div className="img-holder">
                        <img src="images/blog/latest-blog-1.jpg" alt="Awesome Image" />
                        <div className="overlay-style-one">
                          <div className="box">
                            <div className="content">
                              <a href="blog-single"><i className="fa fa-link" aria-hidden="true" /></a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-holder">
                        <div className="categories">
                          <a href="#">Materials</a>    
                        </div>
                        <a href="blog-single">
                          <h3 className="blog-title">Materials for the carbohydrate economy.</h3>
                        </a>
                        <ul className="meta-info">
                          <li><a href="#">March 21, 2017</a></li>
                          <li><a href="#">20 Comments</a></li>
                        </ul>
                        <div className="text">
                          <p>How all this mistaken idea of denouncing pleasure and praising pain was expound…</p>
                        </div>
                      </div>     
                    </div>    
                  </div>*/}
                  {/*End single blog item*/}
                  {/*Start single blog item*/}
                  {/* <div className="col-md-6">
                    <div className="single-blog-item">
                      <div className="img-holder">
                        <img src="images/blog/latest-blog-2.jpg" alt="Awesome Image" />
                        <div className="overlay-style-one">
                          <div className="box">
                            <div className="content">
                              <a href="blog-single"><i className="fa fa-link" aria-hidden="true" /></a>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="text-holder">
                        <div className="categories">
                          <a href="#">Technology, Company</a>    
                        </div>
                        <a href="blog-single">
                          <h3 className="blog-title">Best factory award of the year 2016.</h3>
                        </a>
                        <ul className="meta-info">
                          <li><a href="#">February 16, 2017</a></li>
                          <li><a href="#">14 Comments</a></li>
                        </ul>
                        <div className="text">
                          <p>The great explorer of the truth, master human no  rejects, dislikes, or avoids pleasure itself...</p>
                        </div>
                      </div>    
                    </div>    
                  </div> */}
                  {/*End single blog item*/}
                {/* </div>
              </div>
            </div> */}
            {/* <div className="col-md-4">
              <div className="latest-blog-right"> */}
                {/*Start single blog post*/}
                {/* <div className="single-blog-item first">
                  <div className="text-holder">
                    <div className="categories">
                      <a href="#">Manufacturing</a>    
                    </div>
                    <a href="blog-single">
                      <h3 className="blog-title">How to find good engineers?</h3>
                    </a>
                    <ul className="meta-info">
                      <li><a href="#">February 27, 2017</a></li>
                      <li><a href="#">24 Comments</a></li>
                    </ul>
                    <div className="text">
                      <p>Who loves or pursues or desires to obtain pain of  it is pain, but because occasionally...</p>
                    </div>
                  </div>    
                </div> */}
                {/*End single blog post*/}
                {/*Start single blog post*/}
                {/* <div className="single-blog-item">
                  <div className="text-holder">
                    <div className="categories">
                      <a href="#">Environment</a>    
                    </div>
                    <a href="blog-single">
                      <h3 className="blog-title">We have a great work environment.</h3>
                    </a>
                    <ul className="meta-info">
                      <li><a href="#">February 08, 2017</a></li>
                      <li><a href="#">29 Comments</a></li>
                    </ul>
                    <div className="text">
                      <p>Master-builder of human happiness one rejects, dislikes,  avoids pleasure itself pursue...</p>
                    </div>
                  </div>    
                </div> */}
                {/*End single blog post*/}  
              {/* </div>
            </div>
          </div>
        </div>
      </section> */}
      {/*End latest blog area*/}

      {/*Start slogan area*/}
      <section className="slogan-area">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <div className="text pull-left">
                <h2>We are providing good &amp; on time services to our valuable customers.</h2>
              </div>
              <div className="button pull-right">
                <a href="#">Request a Quote</a>
              </div>
            </div>
          </div>
        </div>    
      </section>                   
      {/*End slogan area*/}

      {/*Start Brand area*/}  
      <section className="brand-area">
        <div className="container">
          <div className="title text-center">
            <h2>We work with our partners to provide project perfection, <span>join with our parnership.</span></h2>
          </div>
          <div className="row">
            <div className="col-md-12">
              <div className="brand">
                {/*Start single item*/}
                <a className="tool_tip" title="Media Partner" href="#">
                  <div className="single-item">
                    <div className="inner-box">
                      <img src="images/brand/1.png" alt="Awesome Brand Image" />
                    </div>
                  </div>
                </a>
                {/*End single item*/}
                {/*Start single item*/}
                <a className="tool_tip" title="Media Partner" href="#">
                  <div className="single-item">
                    <div className="inner-box">
                      <img src="images/brand/2.png" alt="Awesome Brand Image" />
                    </div>
                  </div>
                </a>
                {/*End single item*/}
                {/*Start single item*/}
                <a className="tool_tip" title="Media Partner" href="#">
                  <div className="single-item">
                    <div className="inner-box">
                      <img src="images/brand/3.png" alt="Awesome Brand Image" />
                    </div>    
                  </div>
                </a>
                {/*End single item*/}
                {/*Start single item*/}
                <a className="tool_tip" title="Media Partner" href="#">
                  <div className="single-item" title="Media Partner">
                    <div className="inner-box">
                      <img src="images/brand/4.png" alt="Awesome Brand Image" />
                    </div>
                  </div>
                </a>
                {/*End single item*/}
                {/*Start single item*/}
                <a className="tool_tip" title="Media Partner" href="#">
                  <div className="single-item">
                    <div className="inner-box">
                      <img src="images/brand/5.png" alt="Awesome Brand Image" />
                    </div>
                  </div>
                </a>
                {/*End single item*/}
              </div>
            </div>
          </div>
        </div>
      </section>
      {/*End Brand area*/}
        </div>
    )
}

export default Home
