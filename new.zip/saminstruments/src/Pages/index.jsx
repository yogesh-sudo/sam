import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Footer from '../Components/common/Footer'
import Navbar from '../Components/common/Navbar'
import About from './About'
import Contact from './Contact'
import Home from './Home'
import NotFound from './NotFound'
import Products from './Products'
import SingleProduct from './SingleProduct'

const index = () => {
    return (
        <div className="boxed_wrapper">
            {/* <div className="preloader"></div> */}
            <Navbar />
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/contact" element={<Contact/>}/>
                <Route path="/products" element={<Products/>}/>
                <Route path="/about" element={<About/>}/>
                <Route path="/products/product" element={<SingleProduct/>}/>
                <Route path="*" element={<NotFound/>} />
                </Routes>
            <Footer />
        </div>
    )
}

export default index
