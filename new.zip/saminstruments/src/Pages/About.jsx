import React from 'react'

const About = () => {
    return (
        <div>
            <div>
        {/*Start breadcrumb area*/}     
        <section className="breadcrumb-area" style={{backgroundImage: 'url(images/resources/breadcrumb-bg.jpg)'}}>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="breadcrumbs">
                  <h1>About Us</h1>
                </div>
              </div>
            </div>
          </div>
          <div className="breadcrumb-botton">
            <div className="container">
              <div className="row">
                <div className="col-md-12">
                  <ul className="left pull-left">
                    <li><a href="/">Home</a></li>
                    <li><i className="fa fa-angle-right" aria-hidden="true" /></li>
                    <li className="active">About Us</li>
                  </ul>
                  <div className="share-button pull-right">
                    <a href="#"><i className="fa fa-share-alt" aria-hidden="true" />Share</a>    
                  </div>    
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*End breadcrumb area*/} 
        {/*Start about company area*/} 
        <section className="about-company-area">
          <div className="container">
            <div className="sec-title">
              <h1>About Our Industry</h1>
              <span className="border" />
            </div>
            <div className="row">
              <div className="col-md-6">
                <div className="img-holder">
                  <img src="images/about/about-industry.jpg" alt="Awesome Image" />
                </div>
              </div>
              <div className="col-md-6">
                <div className="text-holder">
                  <p>Over 24 years experience and knowledge international standards, technologicaly changes and industrial systems, we are dedicated to provides seds the best and economical solutions to our valued customers.</p>
                  <div className="title">
                    <h3>History in Words</h3>
                  </div>
                  <p>We partner with over 320 amazing seds projects worldwide, and have given over million in cash &amp; product grants to other groups since 2015 our own dynamic suite.</p>
                  <ul>
                    <li><i className="fa fa-check" aria-hidden="true" />This mistaken idea of denouncing pleasure</li>
                    <li><i className="fa fa-check" aria-hidden="true" />Master-builder of human happiness</li>
                    <li><i className="fa fa-check" aria-hidden="true" />Occasionally circumstances occur in  toil</li>
                    <li><i className="fa fa-check" aria-hidden="true" />Undertakes laborious physical exercise</li>
                  </ul>
                </div>   
              </div>
            </div>
            <div className="row bottom">
              {/*Start single item*/}
              <div className="col-md-6">
                <div className="single-item hvr-wobble-horizontal">
                  <div className="img-holder">
                    <img src="images/about/industry-thumb-1.jpg" alt="Awesome Image" />
                  </div>
                  <div className="text-holder">
                    <h3>Our Mission</h3>
                    <p>We have facility to produce advance work various industrial applications based on specially developed tech- nology are also ready.</p>
                  </div>
                </div>
              </div>
              {/*End single item*/}
              {/*Start single item*/}
              <div className="col-md-6">
                <div className="single-item hvr-wobble-horizontal">
                  <div className="img-holder">
                    <img src="images/about/industry-thumb-2.jpg" alt="Awesome Image" />
                  </div>
                  <div className="text-holder">
                    <h3>Our Vision</h3>
                    <p>Complete account of  work system, andexpound the actual teachings of the truth must explain to you how this mistaken idea praising.</p>
                  </div>
                </div>
              </div>
              {/*End single item*/}
            </div>
          </div>
        </section>    
        {/*End about company area*/}
        {/*Start fact counter area*/}
        <section className="fact-counter-area" style={{backgroundImage: 'url(images/resources/fact-counter-bg.jpg)'}}>
          <div className="container">
            <div className="row">
              {/*Start single item*/}
              <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div className="single-item">
                  <div className="text-holder pull-left">
                    <h1><span className="timer" data-from={1} data-to={1846} data-speed={5000} data-refresh-interval={50}>1846+</span></h1>
                    <h3>Projects Completed</h3>
                  </div>
                  <div className="icon-holder pull-right">
                    <span className="flaticon-technology" />    
                  </div>
                </div>
              </div>
              {/*Start single item*/}
              {/*Start single item*/}
              <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div className="single-item">
                  <div className="text-holder pull-left">
                    <h1><span className="timer" data-from={1} data-to={762} data-speed={5000} data-refresh-interval={50}>762</span></h1>
                    <h3>Team Members</h3>
                  </div>
                  <div className="icon-holder pull-right">
                    <span className="flaticon-people" />    
                  </div>
                </div>
              </div>
              {/*Start single item*/}
              {/*Start single item*/}
              <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div className="single-item">
                  <div className="text-holder pull-left">
                    <h1><span className="timer" data-from={1} data-to={124} data-speed={5000} data-refresh-interval={50}>124+</span></h1>
                    <h3>Branches Running</h3>
                  </div>
                  <div className="icon-holder pull-right">
                    <span className="flaticon-landscape" />    
                  </div>
                </div>
              </div>
              {/*Start single item*/}
              {/*Start single item*/}
              <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div className="single-item">
                  <div className="text-holder pull-left">
                    <h1><span className="timer" data-from={1} data-to={64} data-speed={5000} data-refresh-interval={50}>64</span></h1>
                    <h3>Awards Holded</h3>
                  </div>
                  <div className="icon-holder pull-right">
                    <span className="flaticon-medal" />    
                  </div>
                </div>
              </div>
              {/*Start single item*/}
            </div>
          </div>
        </section>
        {/*End fact counter area*/}
        {/*Start team area*/}
        <section className="team-area">
          <div className="container">
            <div className="sec-title text-center">
              <h1>Meet Our Team</h1>
              <span className="border center" />
            </div>
            <div className="row">
              {/*Start single team member*/}
              <div className="col-md-3 col-sm-6 col-xs-12">
                <div className="single-team-member hvr-float-shadow text-center">
                  <div className="img-holder">
                    <img src="images/team/team-1.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <ul>
                            <li><a href="#"><i className="fa fa-facebook" aria-hidden="true" /></a></li>
                            <li><a href="#"><i className="fa fa-twitter" aria-hidden="true" /></a></li>
                            <li><a href="#"><i className="fa fa-linkedin" aria-hidden="true" /></a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-holder">
                    <div className="top">
                      <h3>Felicity BNovak</h3>
                      <span>CEO &amp; Founder</span>
                    </div>
                    <div className="botton">
                      <p>Denouncing pleasure &amp; praising pain was born and I will give you a complete account system.</p>
                    </div>
                  </div>    
                </div> 
              </div>
              {/*End single team member*/}
              {/*Start single team member*/}
              <div className="col-md-3 col-sm-6 col-xs-12">
                <div className="single-team-member hvr-float-shadow text-center">
                  <div className="img-holder">
                    <img src="images/team/team-2.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <ul>
                            <li><a href="#"><i className="fa fa-facebook" aria-hidden="true" /></a></li>
                            <li><a href="#"><i className="fa fa-twitter" aria-hidden="true" /></a></li>
                            <li><a href="#"><i className="fa fa-linkedin" aria-hidden="true" /></a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-holder">
                    <div className="top">
                      <h3>Mark Richarson</h3>
                      <span>Engineer</span>
                    </div>
                    <div className="botton">
                      <p> Great explorers the truth maters builder of human happiness no one rejects avoids pleasure.</p>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single team member*/}
              {/*Start single team member*/}
              <div className="col-md-3 col-sm-6 col-xs-12">
                <div className="single-team-member hvr-float-shadow text-center">
                  <div className="img-holder">
                    <img src="images/team/team-3.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <ul>
                            <li><a href="#"><i className="fa fa-facebook" aria-hidden="true" /></a></li>
                            <li><a href="#"><i className="fa fa-twitter" aria-hidden="true" /></a></li>
                            <li><a href="#"><i className="fa fa-linkedin" aria-hidden="true" /></a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-holder">
                    <div className="top">
                      <h3>Jom Caraleno</h3>
                      <span>HR Manager</span>
                    </div>
                    <div className="botton">
                      <p>Loves or pursues desires obtain pain of itself, because it is pain, but occasionally circumstances.</p>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single team member*/}
              {/*Start single team member*/}
              <div className="col-md-3 col-sm-6 col-xs-12">
                <div className="single-team-member hvr-float-shadow text-center">
                  <div className="img-holder">
                    <img src="images/team/team-4.jpg" alt="Awesome Image" />
                    <div className="overlay-style-one">
                      <div className="box">
                        <div className="content">
                          <ul>
                            <li><a href="#"><i className="fa fa-facebook" aria-hidden="true" /></a></li>
                            <li><a href="#"><i className="fa fa-twitter" aria-hidden="true" /></a></li>
                            <li><a href="#"><i className="fa fa-linkedin" aria-hidden="true" /></a></li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-holder">
                    <div className="top">
                      <h3>Asahtan Marsh</h3>
                      <span>Head of Research</span>
                    </div>
                    <div className="botton">
                      <p>Ever undertake laborious except to obtain seds advantage from but any right to find fault.</p>
                    </div>
                  </div>   
                </div> 
              </div>
              {/*End single team member*/}
            </div>
          </div>
        </section>
        {/*End team area*/}
        {/*Start slogan area*/}
        <section className="slogan-area">
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="text pull-left">
                  <h2>We are providing good &amp; on time services to our valuable customers.</h2>
                </div>
                <div className="button pull-right">
                  <a href="#">Request a Quote</a>
                </div>
              </div>
            </div>
          </div>    
        </section>                   
        {/*End slogan area*/}
      </div>

        </div>
    )
}

export default About
