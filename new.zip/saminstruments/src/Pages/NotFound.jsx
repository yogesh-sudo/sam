import React from 'react'
import { Link } from 'react-router-dom'

const NotFound = () => {
    return (
        <>
              {/*Start breadcrumb area*/}     
              <section className="breadcrumb-area" style={{backgroundImage: 'url(images/resources/breadcrumb-bg.jpg)'}}>
          <div className="container">
            <div className="row">
              <div className="col-md-12">
                <div className="breadcrumbs">
                  <h1>Page Note Found</h1>
                </div>
              </div>
            </div>
          </div>
          <div className="breadcrumb-botton">
            <div className="container">
              <div className="row">
                <div className="col-md-12">
                  <ul className="left pull-left">
                    <li><a href="/">Home</a></li>
                    <li><i className="fa fa-angle-right" aria-hidden="true" /></li>
                    <li className="active">Page Note Found</li>
                  </ul>
                  <div className="share-button pull-right">
                    <Link to="#"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>    
                  </div>    
                </div>
              </div>
            </div>
          </div>
        </section>
        {/*End breadcrumb area*/}
        </>
    )
}

export default NotFound
