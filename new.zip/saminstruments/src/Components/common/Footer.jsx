import React from 'react'

const Footer = () => {
    return (
        <div>
            {/*Start footer area*/}  
      <footer className="footer-area">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <ul className="footer-contact-info">
                <li><span className="flaticon-phone" /><b>Phone:</b>+91 9818131210</li>
                <li><span className="flaticon-arrows" /><b>Address:</b> Flat No. 505 Shivlok Apartment <span style={{textAlign:'end',display:'block'}}> Sector-21D, Faridabad-121001</span></li>
                <li><span className="flaticon-clock" /><b>Working Hrs:</b> Mon - Sat: 9am to 18pm</li>
              </ul>
            </div>
          </div>
        </div>
        <div className="container">
          <div className="row">
            {/*Start single footer widget*/}
            <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12">
              <div className="single-footer-widget pd-bottom50">
                <div className="title">
                  <h3>about Us</h3>
                </div>
                <div className="about-us">
                  <p>Over 24 years experience and knowledge international standards, technologicaly changes our industrial systems, we are dedicated to provides  the best solutions to our valued customers there are many variations solutions.</p>
                  <ul className="footer-social-links">
                    <li><a href=" "><i className="fa fa-facebook" /></a></li>
                    <li><a href=" "><i className="fa fa-twitter" /></a></li>
                    <li><a href=" "><i className="fa fa-google-plus" /></a></li>
                    <li><a href=" "><i className="fa fa-linkedin" /></a></li>
                  </ul>
                </div>
              </div>
            </div>
            {/*End single footer widget*/}
            {/*Start single footer widget*/}
            <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12">
              <div className="single-footer-widget marginlft pd-bottom50">
                <div className="title">
                  <h3>Usefull Links</h3>
                </div>
                <ul className="usefull-links">
                  <li><a href=" "><i className="fa fa-angle-right" aria-hidden="true" />Agriculture Processing</a></li>
                  <li><a href=" "><i className="fa fa-angle-right" aria-hidden="true" />Mechanical Engineering</a></li>
                  <li><a href=" "><i className="fa fa-angle-right" aria-hidden="true" />Chemical Research</a></li>
                  <li><a href=" "><i className="fa fa-angle-right" aria-hidden="true" />Petroleum and Gas</a></li>
                  <li><a href=" "><i className="fa fa-angle-right" aria-hidden="true" />Material Engineering</a></li>
                  <li><a href=" "><i className="fa fa-angle-right" aria-hidden="true" />Power and Energy</a></li>
                </ul>
              </div>
            </div>
            {/*End single footer widget*/}
            {/*Start single footer widget*/}
            <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12">
              <div className="single-footer-widget">
                <div className="title">
                  <h3>Recent Post</h3>
                </div>
                <ul className="recent-post">
                  <li className="single-post">
                    <div className="icon-holder">
                      <span className="flaticon-arrows-1" />
                    </div>
                    <div className="text-holder">
                      <a className="post-title" href=" ">Best factory award of the year</a>
                      <div className="post-info">
                        <span>March 14, 2017</span>
                      </div>
                    </div>
                  </li>
                  <li className="single-post">
                    <div className="icon-holder">
                      <span className="flaticon-arrows-1" />
                    </div>
                    <div className="text-holder">
                      <a className="post-title" href=" ">Our great working environment</a>
                      <div className="post-info">
                        <span>February 27, 2017</span>
                      </div>
                    </div>
                  </li>
                  <li className="single-post">
                    <div className="icon-holder">
                      <span className="flaticon-arrows-1" />
                    </div>
                    <div className="text-holder">
                      <a className="post-title" href=" ">How to find good engineers?</a>
                      <div className="post-info">
                        <span>January 05, 2017</span>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            {/*Start single footer widget*/}
            {/*Start single footer widget*/}
            <div className="col-lg-3 col-md-6 col-sm-6 col-xs-12">
              <div className="single-footer-widget newsletter pd-lefttop margin-top">
                <div className="title">
                  <h3>Newsletter</h3>
                </div>
                <div className="newsletter-form">
                  <p>Subscribe to our nesletter, We don’t do mail to spam &amp; your mail id is very confidential.</p> 
                  <form action=" ">
                    <input type="email" name="email" placeholder="Email address" defaultValue='' required/>
                    <div className="icon-holder">
                      <span className="flaticon-envelope" />
                    </div>
                    <button type="submit">Subscribe Us</button>
                  </form>
                </div>
              </div>
            </div>
            {/*End single footer widget*/}
          </div>
        </div>
      </footer>   
      {/*End footer area*/}
      
 {/*Start copyright area*/}
 <section className="copyright-area">
        <div className="container">   
          <div className="row">
            <div className="col-md-6 col-sm-12">
              <div className="support">
                <p><span className="flaticon-envelope" />Any Queries: <a href="mailto:name@email.com">Support@saminstuments.com</a></p> 
              </div>
            </div>
            <div className="col-md-6 col-sm-12">
              <div className="copyright">
                <p>Copyrights © 2017 All Rights Reserved. Powered by <a href=" " >SAM INSTRUMENTS</a></p>
              </div>
            </div>
          </div> 
        </div>  
      </section>
      {/*End copyright area*/}

        </div>
    )
}

export default Footer
