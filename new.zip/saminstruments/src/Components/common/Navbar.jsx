import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => {
    return (
        <div>
        {/*Start top bar area*/}
      <section className="top-bar-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-8 col-md-10 col-sm-12 col-xs-12">
              <div className="top-left clearfix">
                {/* <div className="our-office">
                  <select className="selectmenu">
                    <option selected="selected">Newyork Office</option>
                    <option>Austria Office</option>
                    <option>Canada Office</option>
                    <option>France Office</option>
                    <option>Mexico Office</option>
                  </select>
                </div> */}
                <ul className="top-contact-info">
                  <li><span className="flaticon-phone" />+91 9818131210</li>    
                  <li><span className="flaticon-arrows" /> 505 Shivlok Apartment Sector-21D</li>    
                </ul>   
              </div>
            </div>
            <div className="col-lg-4 col-md-2 col-sm-12 col-xs-12">
              <div className="top-right">
                <ul className="social-links">
                  <li><Link to="#"><i className="fa fa-facebook" /></Link></li>
                  <li><Link to="#"><i className="fa fa-twitter" /></Link></li>
                  <li><Link to="#"><i className="fa fa-google-plus" /></Link></li>
                  <li><Link to="#"><i className="fa fa-pinterest-p" /></Link></li>
                  <li><Link to="#"><i className="fa fa-youtube" /></Link></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/*End top bar area*/}
      {/*Start header area*/} 
      <section className="header-area">
        <div className="container">
          <div className="row">
            <div className="col-lg-5 col-md-3">
              <div className="logo">
                <a href="/">
                  <img src="images/resources/logo.png" alt="Awesome Logo" />
                </a>
              </div>
            </div>
            <div className="col-lg-7 col-md-9">
              <div className="header-right">
                <ul>
                  <li>
                    <div className="icon-holder">
                      <span className="flaticon-office" />
                    </div>
                    <div className="text-holder">
                      <h4>Certified Company</h4>
                      <span>ISO 9001:2005</span>    
                    </div>
                  </li>
                  <li>
                    <div className="icon-holder">
                      <span className="flaticon-cup" />
                    </div>
                    <div className="text-holder">
                      <h4>The Best Industrial</h4>
                      <span>Solution Provider</span>    
                    </div>
                  </li>     
                </ul>
                <div className="download-button">
                  <Link to="#"><span className="flaticon-download-to-storage-drive" />Downloads</Link>    
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>   
      {/*End header area*/}

       {/*Start mainmenu area*/}
       <section className="mainmenu-area stricky">
        <div className="container">
          <div className="row">
            <div className="col-lg-12 col-md-12 col-sm-12 col-xs-12">
              {/*Start mainmenu*/}
              <nav className="main-menu pull-left">
                <div className="navbar-header">   	
                  <button type="button" className="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span className="icon-bar" />
                    <span className="icon-bar" />
                    <span className="icon-bar" />
                  </button>
                </div>
                <div className="navbar-collapse collapse clearfix">
                  <ul className="navigation clearfix">
                    <li className="current"><a href="/">Home</a></li>
                    <li className="dropdown"><Link to="" onClick={(e)=>{e.preventDefault()}}>ABOUT US</Link>
                      <ul>
                        <li><Link to="about">About Company</Link></li>
                        {/* <li><Link to="testimonials">Testimonials</Link></li> */}
                        {/* <li><Link to="faq">FAQ’s</Link></li> */}
                      </ul>
                    </li>
                    {/* <li class="dropdown"><Link to="services">Solutions</Link>
                                <ul>
                                    <li><Link to="agriculrute-processing">Agriculrute Processing</Link></li>
                                    <li><Link to="mechanical-engineering">Mechanical Engineering</Link></li>
                                    <li><Link to="chemical-research">Chemical Research</Link></li>
                                    <li><Link to="petroleum-gas">Petroleum and Gas</Link></li>
                                    <li><Link to="material-engineering">Material Engineering</Link></li>
                                    <li><Link to="power-energy">Power and Energy</Link></li>
                                </ul>
                            </li> */}
                    <li className="dropdown">
                      <Link to="" onClick={(e)=>{e.preventDefault()}}>Products</Link>
                      <ul className="dropdown">
                        <li><Link to="/products">Our Products</Link></li>
                        {/* <li><Link to="projects-single">Single Projects</Link></li> */}
                      </ul>
                    </li>
                    {/* <li class="dropdown"><Link to="blog-default">News</Link>
                                <ul>
                                    <li><Link to="blog-default">News Default</Link></li>
                                    <li><Link to="blog-grid">News Grid View</Link></li>
                                    <li><Link to="blog-single">News Single Post</Link></li>
                                </ul>
                            </li> */}
                    <li className="dropdown"><Link to="/Quality">Quality</Link>
                      {/* <ul>
                                    <li><Link to="shop">Shop Products</Link></li>
                                    <li><Link to="shop-single">Products Single</Link></li>
                                    <li><Link to="shopping-cart">Shopping Cart</Link></li>
                                    <li><Link to="checkout">Checkout</Link></li>
                                    <li><Link to="account">My Account</Link></li>
                                </ul> */}
                    </li>
                    <li><Link to="contact">Contact Us</Link></li>
                  </ul>
                </div>
              </nav>
              {/*End mainmenu*/}
              <div className="mainmenu-right-box pull-right">
                <div className="quote-button">
                  <Link to="#"><i className="fa fa-share" aria-hidden="true" />Request Quote</Link>
                </div>
                <div className="search-option">
                  <div className="outer-search-box">
                    <div className="seach-toggle"><i className="fa fa-search" /></div>
                    <ul className="search-box">
                      <li>
                        <form method="post" action="index">
                          <div className="form-group">
                            <input type="search" name="search" placeholder="Search Here" required />
                            <button type="submit"><i className="fa fa-search" /></button>
                          </div>
                        </form>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>    
            </div>
          </div>
        </div>
      </section>      
      {/*End mainmenu area*/}
        </div>
    )
}

export default Navbar
