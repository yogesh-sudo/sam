jQuery(window).on("load", function () {
    $('#preloader').fadeOut(500);
    $('#main-wrapper').addClass('show');
});


jQuery(document).ready(function () {
    $('.earn_possibilities-content')
        .on('click', function () {
            $(".earn_possibilities-content.active")
                .removeClass("active");
            $(this)
                .addClass('active');
        });

    $('.bonus_card')
        .on('click', function () {
            $(".bonus_card.active")
                .removeClass("active");
            $(this)
                .addClass('active');
        });

    $('.game_skin-category-list li')
        .on('click', function () {
            $(".game_skin-category-list li.active")
                .removeClass("active");
            $(this)
                .addClass('active');
        });

    $('.duration-option a')
        .on('click', function () {
            $(".duration-option a.active")
                .removeClass("active");
            $(this)
                .addClass('active');
        });
    $('.choose_amount li')
        .on('click', function () {
            $(".choose_amount li.active")
                .removeClass("active");
            $(this)
                .addClass('active');
        });
    $('.crypto_currencies li')
        .on('click', function () {
            $(".crypto_currencies li.active")
                .removeClass("active");
            $(this)
                .addClass('active');
        });

    $(".game_skin-card").click(function () {
        $(this).toggleClass("active");
    });


    $('.cart_count').on('click', function () {
        $(".cart_right_sidebar").addClass("active");
    });
    $('.cart_sidebar_close').on('click', function () {
        $(".cart_right_sidebar").removeClass("active");
    });










    $(".see_all").click(function () {
        $(this).text(function (i, v) {
            return v === 'Hide All' ? 'See All' : 'Hide All'
        });
        $(".all_items").slideToggle();
    });

    $('.all_items').hide();


    /*==============================================
		Select Box js
		 ===============================================*/


    $('.drop-menu').click(function () {
        $(this).attr('tabindex', 1).focus();
        $(this).toggleClass('active');
        $(this).find('.dropeddown').slideToggle(300);
    });
    $('.drop-menu').focusout(function () {
        $(this).removeClass('active');
        $(this).find('.dropeddown').slideUp(300);
    });
    $('.drop-menu .dropeddown li').click(function () {
        $(this).parents('.drop-menu').find('span').text($(this).text());
        $(this).parents('.drop-menu').find('input').attr('value', $(this).attr('id'));
    });

    $(function () {
        for (var nk = window.location,
            o = $(".menu a").filter(function () {
                return this.href == nk;
            })
                .addClass("active")
                .parent()
                .addClass("active"); ;) {
            // console.log(o)
            if (!o.is("li")) break;
            o = o.parent()
                .addClass("show")
                .parent()
                .addClass("active");
        }

    });



});











//ripple effect on button
Waves.init();
Waves.attach('.wave-effect');
Waves.attach('.btn');
Waves.attach('button');